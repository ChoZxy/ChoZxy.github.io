package com.example.ioc.model;

public interface Player {

    String sayHi();

}
