package com.example.ioc.model;

import lombok.Data;

@Data
public class User {

    private Long id;
    private String name;
    private String gender;
    private Integer age;

}
